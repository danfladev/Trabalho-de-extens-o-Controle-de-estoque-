import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import ListagemProdutos from "./screens/ListagemProdutos";
import CadastroProduto from "./screens/CadastroProduto";
import ControleEstoque from "./screens/ControleEstoque";

export type RootStackParamList = {
  ListagemProdutos: undefined;
  CadastroProduto: undefined;
  ControleEstoque: { productId: number };
};

const Stack = createStackNavigator<RootStackParamList>();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="ListagemProdutos">
        <Stack.Screen name="ListagemProdutos" component={ListagemProdutos} />
        <Stack.Screen name="CadastroProduto" component={CadastroProduto} />
        <Stack.Screen name="ControleEstoque" component={ControleEstoque} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
