import { useState } from "react";
import { View, TextInput, Button, StyleSheet } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { StackNavigationProp } from "@react-navigation/stack";
import { RootStackParamList } from "../App";

type CadastroProdutoProps = {
  navigation: StackNavigationProp<RootStackParamList, "CadastroProduto">;
};

const CadastroProduto: React.FC<CadastroProdutoProps> = ({ navigation }) => {
  const [name, setName] = useState<string>("");
  const [quantity, setQuantity] = useState<string>("");

  const handleAddProduct = async () => {
    if (name && quantity) {
      const newProduct = {
        id: Date.now(),
        name,
        quantity: parseInt(quantity),
      };

      try {
        const storedProducts = await AsyncStorage.getItem("produtos");
        let products = storedProducts ? JSON.parse(storedProducts) : [];
        products.push(newProduct);
        await AsyncStorage.setItem("produtos", JSON.stringify(products));
        navigation.reset({
          index: 0,
          routes: [{ name: "ListagemProdutos" }],
        });
      } catch (error) {
        console.error("Erro ao adicionar o produto", error);
      }
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Nome do Produto"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Quantidade"
        value={quantity}
        onChangeText={setQuantity}
        keyboardType="numeric"
      />
      <Button title="Cadastrar Produto" onPress={handleAddProduct} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 16,
  },
  input: {
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    marginBottom: 20,
    paddingLeft: 8,
  },
});

export default CadastroProduto;
