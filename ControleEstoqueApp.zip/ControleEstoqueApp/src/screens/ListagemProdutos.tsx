import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  Button,
  FlatList,
  StyleSheet,
  RefreshControl,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { StackNavigationProp } from "@react-navigation/stack";
import { RootStackParamList } from "../App";
import { useFocusEffect } from "@react-navigation/native";

type Produto = {
  id: number;
  name: string;
  quantity: number;
};

type ListagemProdutosProps = {
  navigation: StackNavigationProp<RootStackParamList, "ListagemProdutos">;
};

const ListagemProdutos: React.FC<ListagemProdutosProps> = ({ navigation }) => {
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [produtos, setProdutos] = useState<Produto[]>([]);

  const loadProducts = async (refreshing: boolean = false) => {
    try {
      if (refreshing) setRefreshing(true);
      const storedProducts = await AsyncStorage.getItem("produtos");
      if (storedProducts) {
        setProdutos(JSON.parse(storedProducts));
      }
    } catch (error) {
      console.error("Erro ao carregar os produtos", error);
    } finally {
      if (refreshing) setRefreshing(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadProducts();
    }, [])
  );

  return (
    <View style={styles.container}>
      <Button
        title="Cadastrar Produto"
        onPress={() => navigation.navigate("CadastroProduto")}
      />
      <Text style={styles.title}>Produtos no Estoque</Text>
      <FlatList
        data={produtos}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.productContainer}>
            <Text>{item.name}</Text>
            <Text>Quantidade: {item.quantity}</Text>
            <Button
              title="Gerenciar Estoque"
              onPress={() =>
                navigation.navigate("ControleEstoque", { productId: item.id })
              }
            />
          </View>
        )}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => loadProducts(true)}
          />
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: "100%",
    justifyContent: "center",
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  productContainer: {
    padding: 10,
    borderBottomWidth: 1,
    borderColor: "#ccc",
    marginBottom: 10,
  },
});

export default ListagemProdutos;
