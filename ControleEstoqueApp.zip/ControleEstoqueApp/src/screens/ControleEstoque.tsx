import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Button,
  TextInput,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { StackNavigationProp } from "@react-navigation/stack";
import { RouteProp } from "@react-navigation/native";
import { RootStackParamList } from "../App";

type ControleEstoqueProps = {
  route: RouteProp<RootStackParamList, "ControleEstoque">;
  navigation: StackNavigationProp<RootStackParamList, "ControleEstoque">;
};

type Produto = {
  id: number;
  name: string;
  quantity: number;
};

const ControleEstoque: React.FC<ControleEstoqueProps> = ({
  route,
  navigation,
}) => {
  const { productId } = route.params;
  const [product, setProduct] = useState<Produto | null>(null);
  const [quantity, setQuantity] = useState<string>("");

  const loadProduct = async () => {
    try {
      const storedProducts = await AsyncStorage.getItem("produtos");
      if (storedProducts) {
        const products: Produto[] = JSON.parse(storedProducts);
        const foundProduct = products.find((p) => p.id === productId);
        if (foundProduct) {
          setProduct(foundProduct);
        }
      }
    } catch (error) {
      console.error("Erro ao carregar o produto", error);
    }
  };

  useEffect(() => {
    loadProduct();
  }, []);

  const handleUpdateQuantity = async (action: "add" | "remove" | "exclude") => {
    if (product) {
      let newQuantity = product.quantity || 0;

      if (action === "add") {
        newQuantity += parseInt(quantity);
      } else if (action === "remove" && newQuantity >= parseInt(quantity)) {
        newQuantity -= parseInt(quantity);
      }

      const updatedProduct = { ...product, quantity: newQuantity };

      try {
        const storedProducts = await AsyncStorage.getItem("produtos");
        let products = storedProducts ? JSON.parse(storedProducts) : [];
        const updatedProducts =
          action === "exclude"
            ? products.filter((p: Produto) => p.id !== product.id)
            : products.map((p: Produto) =>
                p.id === product.id ? updatedProduct : p
              );

        await AsyncStorage.setItem("produtos", JSON.stringify(updatedProducts));
        setProduct(updatedProduct);

        if (action === "exclude") {
          navigation.reset({
            index: 0,
            routes: [{ name: "ListagemProdutos" }],
          });
        }
      } catch (error) {
        console.error("Erro ao atualizar o estoque", error);
      }
    }
  };

  return (
    <View style={styles.container}>
      {product && (
        <>
          <Text style={styles.title}>Controle de Estoque</Text>
          <TouchableOpacity
            style={{
              justifyContent: "center",
              alignItems: "center",
              backgroundColor: "red",
            }}
            onPress={() => handleUpdateQuantity("exclude")}
          >
            <Text style={{ fontSize: 45 }}>X</Text>
          </TouchableOpacity>
          <Text>Produto: {product.name}</Text>
          <Text>Quantidade: {product.quantity}</Text>
          <TextInput
            style={styles.input}
            placeholder="Quantidade para alterar"
            value={quantity}
            onChangeText={setQuantity}
            keyboardType="numeric"
          />
          <Button
            title="Adicionar Quantidade"
            onPress={() => handleUpdateQuantity("add")}
          />
          <Button
            title="Remover Quantidade"
            onPress={() => handleUpdateQuantity("remove")}
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    marginBottom: 20,
    paddingLeft: 8,
  },
});

export default ControleEstoque;
